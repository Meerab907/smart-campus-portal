﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ViewAttendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadCourses();
            }
        }

        private void LoadCourses()
        {
            string studentUsername = Session["Username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = from sc in db.StudentCourses
                              where sc.StudentUsername == studentUsername
                              join c in db.Courses on sc.CourseID equals c.CourseID
                              select new { c.CourseID, c.CourseName };

                ddlCourses.DataSource = courses.ToList();
                ddlCourses.DataTextField = "CourseName";
                ddlCourses.DataValueField = "CourseID";
                ddlCourses.DataBind();

                if (ddlCourses.Items.Count > 0)
                {
                    ddlCourses_SelectedIndexChanged(null, null);
                }
            }
        }

        protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCourses.SelectedValue != null && int.TryParse(ddlCourses.SelectedValue, out int courseId))
            {
                LoadAttendance(courseId);
            }
        }

        private void LoadAttendance(int courseId)
        {
            string studentUsername = Session["Username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var attendance = from att in db.AttendanceRecords
                                 where att.Username == studentUsername && att.CourseID == courseId
                                 orderby att.AttendanceDate descending
                                 select new { att.AttendanceDate, att.IsPresent };

                gvAttendance.DataSource = attendance.ToList();
                gvAttendance.DataBind();
            }
        }
    }
}
