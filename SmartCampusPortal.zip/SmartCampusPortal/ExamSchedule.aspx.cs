﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class ExamSchedule : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCourses();
                LoadExamSchedules();
            }
        }

        private void LoadCourses()
        {
            ddlCourses.DataSource = db.Courses.Select(c => new { c.CourseID, c.CourseName });
            ddlCourses.DataTextField = "CourseName";
            ddlCourses.DataValueField = "CourseID";
            ddlCourses.DataBind();
            ddlCourses.Items.Insert(0, new ListItem("-- Select --", ""));
        }

        private void LoadExamSchedules()
        {
            var data = from e in db.ExamSchedules
                       join c in db.Courses on e.CourseID equals c.CourseID
                       select new
                       {
                           e.ExamID,
                           c.CourseName,
                           e.ExamDate,
                           e.ExamTime,
                           e.Location
                       };

            gvExamSchedules.DataSource = data.ToList();
            gvExamSchedules.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (ddlCourses.SelectedIndex == 0 || string.IsNullOrWhiteSpace(txtDate.Text) ||
                string.IsNullOrWhiteSpace(txtTime.Text) || string.IsNullOrWhiteSpace(txtLocation.Text))
            {
                // Validation fail
                return;
            }

            ExamSchedule newSchedule = new ExamSchedule
            {
                CourseID = int.Parse(ddlCourses.SelectedValue),
                ExamDate = DateTime.Parse(txtDate.Text),
                ExamTime = TimeSpan.Parse(txtTime.Text),
                Location = txtLocation.Text.Trim()
            };

            db.ExamSchedules.InsertOnSubmit(newSchedule);
            db.SubmitChanges();

            ClearForm();
            LoadExamSchedules();
        }

        protected void gvExamSchedules_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int examId = Convert.ToInt32(gvExamSchedules.DataKeys[e.RowIndex].Value);
            var exam = db.ExamSchedules.SingleOrDefault(x => x.ExamID == examId);
            if (exam != null)
            {
                db.ExamSchedules.DeleteOnSubmit(exam);
                db.SubmitChanges();
                LoadExamSchedules();
            }
        }

        private void ClearForm()
        {
            ddlCourses.SelectedIndex = 0;
            txtDate.Text = "";
            txtTime.Text = "";
            txtLocation.Text = "";
        }
    }
}
