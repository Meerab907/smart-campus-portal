﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblMessage.Text = "";
                pnlLogin.Visible = true;
                pnlSignUp.Visible = false;

                // Clear any old sessions on login page load
                Session.Clear();
            }
        }

        // Login button click handler
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtLoginUsername.Text.Trim();
            string password = txtLoginPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                lblMessage.Text = "Please enter username and password.";
                return;
            }

            try
            {
                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var user = db.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

                    if (user != null)
                    {
                        // Set session variables
                        Session["username"] = user.Username;
                        Session["role"] = user.Role.ToLower();

                        // ✅ Log login activity
                        ActivityLog log = new ActivityLog
                        {
                            Username = user.Username,
                            Action = "Logged in",
                            ActivityTime = DateTime.Now
                        };
                        db.ActivityLogs.InsertOnSubmit(log);
                        db.SubmitChanges();

                        // Redirect based on role
                        switch (Session["role"].ToString())
                        {
                            case "admin":
                                Response.Redirect("~/AdminDashboard.aspx");
                                break;
                            case "faculty":
                                Response.Redirect("~/FacultyDashboard.aspx");
                                break;
                            case "student":
                                Response.Redirect("~/StudentDashboard.aspx");
                                break;
                            default:
                                lblMessage.Text = "User role is not recognized.";
                                break;
                        }
                    }
                    else
                    {
                        lblMessage.Text = "Invalid username or password.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "An error occurred during login. Please try again.";
            }
        }

        // Signup button click handler
        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            string newUsername = txtSignUpUsername.Text.Trim();
            string newEmail = txtSignUpEmail.Text.Trim();
            string newPassword = txtSignUpPassword.Text.Trim();
            string selectedRole = ddlRole.SelectedValue;

            if (string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newEmail) ||
                string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(selectedRole))
            {
                lblMessage.Text = "Please fill in all fields and select a role.";
                return;
            }

            try
            {
                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    // Check if username already exists
                    bool exists = db.Users.Any(u => u.Username == newUsername);
                    if (exists)
                    {
                        lblMessage.Text = "Username already exists. Please choose another.";
                        return;
                    }

                    // Create new user and insert into DB
                    User newUser = new User
                    {
                        Username = newUsername,
                        Email = newEmail,
                        Password = newPassword,  // Remember to hash in production!
                        Role = selectedRole.ToLower()
                    };

                    db.Users.InsertOnSubmit(newUser);

                    // ✅ Log signup activity
                    ActivityLog log = new ActivityLog
                    {
                        Username = newUsername,
                        Action = "Signed up",
                        ActivityTime = DateTime.Now
                    };
                    db.ActivityLogs.InsertOnSubmit(log);

                    db.SubmitChanges();

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Registration successful! Please log in.";

                    // Clear signup fields
                    txtSignUpUsername.Text = "";
                    txtSignUpEmail.Text = "";
                    txtSignUpPassword.Text = "";
                    ddlRole.SelectedIndex = 0;

                    // Switch to login panel
                    pnlSignUp.Visible = false;
                    pnlLogin.Visible = true;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "An error occurred during registration. Please try again.";
            }
        }

        // Link to show sign-up panel
        protected void lnkGoToSignUp_Click(object sender, EventArgs e)
        {
            pnlLogin.Visible = false;
            pnlSignUp.Visible = true;
            lblMessage.Text = "";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }

        // Link to show login panel
        protected void lnkGoToLogin_Click(object sender, EventArgs e)
        {
            pnlLogin.Visible = true;
            pnlSignUp.Visible = false;
            lblMessage.Text = "";
            lblMessage.ForeColor = System.Drawing.Color.Red;
        }
    }
}
