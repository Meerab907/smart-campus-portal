﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class FinancialInfo : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadFinancialInfo();
            }
        }

        private void LoadFinancialInfo()
        {
            string studentUsername = Session["Username"]?.ToString();
            if (string.IsNullOrEmpty(studentUsername))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            var fees = from f in db.StudentFees
                       where f.StudentUsername == studentUsername
                       select new
                       {
                           f.Semester,
                           f.TotalFee,
                           f.PaidAmount,
                           DueAmount = f.TotalFee - f.PaidAmount,
                           f.PaymentStatus
                       };

            gvFees.DataSource = fees.ToList();
            gvFees.DataBind();
        }
    }
}
