﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ViewLecturesQuizzes : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCourses();
            }
        }

        private void LoadCourses()
        {
            string studentUsername = Session["Username"]?.ToString();
            if (string.IsNullOrEmpty(studentUsername))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            var courses = from sc in db.StudentCourses
                          where sc.StudentUsername == studentUsername
                          join c in db.Courses on sc.CourseID equals c.CourseID
                          select new { c.CourseID, c.CourseName };

            ddlCourses.DataSource = courses.ToList();
            ddlCourses.DataTextField = "CourseName";
            ddlCourses.DataValueField = "CourseID";
            ddlCourses.DataBind();

            if (ddlCourses.Items.Count > 0)
                ddlCourses_SelectedIndexChanged(null, null);
        }

        protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            int courseId = int.Parse(ddlCourses.SelectedValue);
            LoadLectures(courseId);
            LoadQuizzes(courseId);
        }

        private void LoadLectures(int courseId)
        {
            var lectures = from lm in db.LectureMaterials
                           where lm.CourseID == courseId
                           select new
                           {
                               lm.Title,
                               lm.UploadDate,
                               lm.FilePath,
                               FileName = System.IO.Path.GetFileName(lm.FilePath)
                           };

            gvLectures.DataSource = lectures.ToList();
            gvLectures.DataBind();
        }

        private void LoadQuizzes(int courseId)
        {
            var quizzes = from q in db.Quizzes
                          where q.CourseID == courseId
                          orderby q.QuizDate descending
                          select new
                          {
                              q.Title,
                              q.QuizDate,
                              q.Description
                          };

            gvQuizzes.DataSource = quizzes.ToList();
            gvQuizzes.DataBind();
        }
    }
}
