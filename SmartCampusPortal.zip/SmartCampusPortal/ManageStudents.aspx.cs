﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ManageStudents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStudents();
                ResetForm();
            }
        }

        private void LoadStudents()
        {
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                // Load only users with Role = "student"
                var students = db.Users
                    .Where(u => u.Role.ToLower() == "student")
                    .Select(u => new
                    {
                        u.Username,
                        u.Email,
                        FullName = u.Username // Assuming no FullName field, replace if you have one
                    }).ToList();

                gvStudents.DataSource = students;
                gvStudents.DataBind();
            }
        }

        private void ResetForm()
        {
            txtUsername.Enabled = true;
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtEmail.Text = "";
            lblFormTitle.Text = "Add New Student";
            btnCancel.Visible = false;
            lblMessage.Text = "";
            hfUsername.Value = "";
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
            {
                lblMessage.Text = "All fields are required!";
                lblMessage.CssClass = "text-danger";
                return;
            }

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                if (string.IsNullOrEmpty(hfUsername.Value))
                {
                    // Add new student
                    // Check if username exists
                    bool exists = db.Users.Any(u => u.Username == username);
                    if (exists)
                    {
                        lblMessage.Text = "Username already exists.";
                        lblMessage.CssClass = "text-danger";
                        return;
                    }

                    User newUser = new User
                    {
                        Username = username,
                        Password = password,  // TODO: Hash password in production!
                        Email = email,
                        Role = "student"
                    };

                    db.Users.InsertOnSubmit(newUser);
                    db.SubmitChanges();

                    lblMessage.Text = "Student added successfully!";
                    lblMessage.CssClass = "text-success";
                }
                else
                {
                    // Edit existing student
                    string originalUsername = hfUsername.Value;
                    var student = db.Users.FirstOrDefault(u => u.Username == originalUsername);
                    if (student != null)
                    {
                        // If username changed, check availability
                        if (!username.Equals(originalUsername, StringComparison.OrdinalIgnoreCase))
                        {
                            if (db.Users.Any(u => u.Username == username))
                            {
                                lblMessage.Text = "Username already exists.";
                                lblMessage.CssClass = "text-danger";
                                return;
                            }
                            student.Username = username;
                        }

                        student.Password = password; // Again, hash in production
                        student.Email = email;
                        db.SubmitChanges();

                        lblMessage.Text = "Student updated successfully!";
                        lblMessage.CssClass = "text-success";
                    }
                    else
                    {
                        lblMessage.Text = "Student not found.";
                        lblMessage.CssClass = "text-danger";
                        return;
                    }
                }
            }

            LoadStudents();
            ResetForm();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        protected void gvStudents_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditStudent")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                string username = gvStudents.DataKeys[rowIndex].Value.ToString();

                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var student = db.Users.FirstOrDefault(u => u.Username == username);
                    if (student != null)
                    {
                        txtUsername.Text = student.Username;
                        txtUsername.Enabled = false;  // Disable editing username
                        txtPassword.Text = student.Password;
                        txtEmail.Text = student.Email;
                        lblFormTitle.Text = "Edit Student";
                        btnCancel.Visible = true;
                        hfUsername.Value = student.Username;
                    }
                }
            }
            else if (e.CommandName == "DeleteStudent")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                string username = gvStudents.DataKeys[rowIndex].Value.ToString();

                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var student = db.Users.FirstOrDefault(u => u.Username == username);
                    if (student != null)
                    {
                        db.Users.DeleteOnSubmit(student);
                        db.SubmitChanges();
                        lblMessage.Text = "Student deleted successfully.";
                        lblMessage.CssClass = "text-success";
                    }
                }
                LoadStudents();
                ResetForm();
            }
        }
    }
}
