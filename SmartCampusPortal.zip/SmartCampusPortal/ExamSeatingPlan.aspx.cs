﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ExamSeatingPlan : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSeatingPlan();
            }
        }

        private void LoadSeatingPlan()
        {
            string studentUsername = Session["Username"]?.ToString();
            if (string.IsNullOrEmpty(studentUsername))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            var plan = from esp in db.ExamSeatingPlans
                       join es in db.ExamSchedules on esp.ExamID equals es.ExamID
                       join c in db.Courses on es.CourseID equals c.CourseID
                       where esp.StudentUsername == studentUsername
                       select new
                       {
                           c.CourseName,
                           es.ExamDate,
                           es.ExamTime,
                           esp.SeatNumber,
                           esp.Room
                       };

            gvSeatingPlan.DataSource = plan.ToList();
            gvSeatingPlan.DataBind();
        }
    }
}
