﻿using System;
using System.IO;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class RegisteredCoursesAssignments : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadRegisteredCourses();
            }
        }

        private void LoadRegisteredCourses()
        {
            string studentUsername = Session["Username"]?.ToString();
            if (string.IsNullOrEmpty(studentUsername))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            var courses = from sc in db.StudentCourses
                          where sc.StudentUsername == studentUsername
                          join c in db.Courses on sc.CourseID equals c.CourseID
                          select new { c.CourseID, c.CourseName, c.Credits };

            gvCourses.DataSource = courses.ToList();
            gvCourses.DataBind();

            pnlAssignments.Visible = false;
            pnlSubmitAssignment.Visible = false;
        }

        protected void gvCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            int courseId = (int)gvCourses.SelectedDataKey.Value;
            lblSelectedCourse.Text = gvCourses.SelectedRow.Cells[1].Text;
            LoadAssignments(courseId);
            pnlAssignments.Visible = true;
            pnlSubmitAssignment.Visible = false;
        }

        private void LoadAssignments(int courseId)
        {
            string studentUsername = Session["Username"].ToString();

            var assignments = from a in db.Assignments
                              where a.CourseID == courseId
                              select new
                              {
                                  a.AssignmentID,
                                  a.Title,
                                  a.DueDate,
                                  IsGraded = db.AssignmentSubmissions.Any(s => s.AssignmentID == a.AssignmentID && s.StudentUsername == studentUsername && s.IsGraded)
                              };

            gvAssignments.DataSource = assignments.ToList();
            gvAssignments.DataBind();
        }

        protected void gvAssignments_SelectedIndexChanged(object sender, EventArgs e)
        {
            int assignmentId = (int)gvAssignments.SelectedDataKey.Value;
            var assignment = db.Assignments.Single(a => a.AssignmentID == assignmentId);
            lblAssignmentTitle.Text = assignment.Title;

            // Load existing submission if any
            string studentUsername = Session["Username"].ToString();
            var submission = db.AssignmentSubmissions.FirstOrDefault(s => s.AssignmentID == assignmentId && s.StudentUsername == studentUsername);

            pnlSubmitAssignment.Visible = true;
            lblSubmitMessage.Text = "";
            lblSubmitError.Text = "";

            if (submission != null)
            {
                // If already submitted, show message or disable
                if (submission.IsGraded)
                {
                    lblSubmitMessage.Text = $"Assignment already graded. Grade: {submission.Grade}";
                    btnSubmitAssignment.Enabled = false;
                    fuAssignment.Visible = false;
                    txtNotes.Visible = false;
                }
                else
                {
                    lblSubmitMessage.Text = "You have already submitted this assignment. You can update your submission.";
                    btnSubmitAssignment.Enabled = true;
                    fuAssignment.Visible = true;
                    txtNotes.Visible = true;
                    txtNotes.Text = submission.Notes;
                }
            }
            else
            {
                btnSubmitAssignment.Enabled = true;
                fuAssignment.Visible = true;
                txtNotes.Visible = true;
                txtNotes.Text = "";
            }

            ViewState["CurrentAssignmentID"] = assignmentId;
        }

        protected void btnSubmitAssignment_Click(object sender, EventArgs e)
        {
            int assignmentId = (int)ViewState["CurrentAssignmentID"];
            string studentUsername = Session["Username"].ToString();

            var submission = db.AssignmentSubmissions.FirstOrDefault(s => s.AssignmentID == assignmentId && s.StudentUsername == studentUsername);
            string filePath = null;

            if (fuAssignment.HasFile)
            {
                string folderPath = Server.MapPath("~/AssignmentSubmissions/");
                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);

                string fileName = $"{studentUsername}_{assignmentId}_{DateTime.Now.Ticks}_{fuAssignment.FileName}";
                filePath = Path.Combine(folderPath, fileName);
                fuAssignment.SaveAs(filePath);

                // Store relative path for DB
                filePath = "~/AssignmentSubmissions/" + fileName;
            }

            if (submission == null)
            {
                submission = new AssignmentSubmission
                {
                    AssignmentID = assignmentId,
                    StudentUsername = studentUsername,
                    SubmissionDate = DateTime.Now,
                    FilePath = filePath,
                    Notes = txtNotes.Text.Trim(),
                    IsGraded = false
                };
                db.AssignmentSubmissions.InsertOnSubmit(submission);
            }
            else
            {
                submission.SubmissionDate = DateTime.Now;
                if (filePath != null) submission.FilePath = filePath;
                submission.Notes = txtNotes.Text.Trim();
                submission.IsGraded = false;
            }

            db.SubmitChanges();

            lblSubmitMessage.Text = "Assignment submitted successfully!";
            pnlSubmitAssignment.Visible = false;
        }
    }
}
