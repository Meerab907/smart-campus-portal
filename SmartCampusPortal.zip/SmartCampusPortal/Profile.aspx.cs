﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class Profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Username"] != null)
                {
                    string username = Session["Username"].ToString();
                    LoadProfile(username);
                }
                else
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        private void LoadProfile(string username)
        {
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Username == username);
                if (user != null)
                {
                    var profile = db.UserProfiles.FirstOrDefault(p => p.UserID == user.UserID);

                    if (profile != null)
                    {
                        pnlProfileView.Visible = true;
                        pnlAddProfile.Visible = false;

                        lblName.Text = profile.FullName;
                        lblEmail.Text = profile.Email;
                        lblDOB.Text = profile.DateOfBirth?.ToString("yyyy-MM-dd");
                        lblArea.Text = profile.AreaOfResidence;
                        lblEducation.Text = profile.EducationDetails;
                    }
                    else
                    {
                        pnlProfileView.Visible = false;
                        pnlAddProfile.Visible = true;
                    }
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Session["Username"] != null)
            {
                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    string username = Session["Username"].ToString();
                    var user = db.Users.FirstOrDefault(u => u.Username == username);

                    if (user != null)
                    {
                        UserProfile newProfile = new UserProfile
                        {
                            UserID = user.UserID,
                            FullName = txtFullName.Text.Trim(),
                            Email = txtEmail.Text.Trim(),
                            DateOfBirth = DateTime.TryParse(txtDOB.Text.Trim(), out var dob) ? dob : (DateTime?)null,
                            AreaOfResidence = txtArea.Text.Trim(),
                            EducationDetails = txtEducation.Text.Trim()
                        };

                        db.UserProfiles.InsertOnSubmit(newProfile);
                        db.SubmitChanges();

                        lblMessage.Text = "Profile saved successfully!";
                        LoadProfile(username); // Reload to switch view
                    }
                }
            }
        }
    }
}
