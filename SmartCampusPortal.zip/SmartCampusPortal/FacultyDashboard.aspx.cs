﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class FacultyDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Session check
            if (Session["username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                lblWelcome.Text = $"Welcome, {Session["username"]}";
                LoadFacultyAssignments();
            }
        }

        private void LoadFacultyAssignments()
        {
            try
            {
                string currentFacultyUsername = Session["username"].ToString();

                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var assignments = (from a in db.Assignments
                                       join c in db.Courses on a.CourseID equals c.CourseID
                                       where c.FacultyUsername == currentFacultyUsername
                                       select new
                                       {
                                           a.Title,
                                           a.Description,
                                           a.DueDate,
                                           a.IsGraded,
                                           CourseName = c.CourseName
                                       }).ToList();

                    if (assignments.Any())
                    {
                        gvAssignments.DataSource = assignments;
                        gvAssignments.DataBind();
                        lblMessage.Text = "";
                    }
                    else
                    {
                        gvAssignments.DataSource = null;
                        gvAssignments.DataBind();
                        lblMessage.Text = "No assignments found for your assigned courses.";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "An error occurred while loading assignments.";
                // Optionally log ex.Message
            }
        }
    }
}
