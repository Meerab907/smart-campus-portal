﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class AssignFaculty : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCourses();
            }
        }

        private void BindCourses()
        {
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = db.Courses.Select(c => new
                {
                    c.CourseID,
                    c.CourseName,
                    c.FacultyUsername
                }).ToList();

                gvCourses.DataSource = courses;
                gvCourses.DataBind();
            }
        }

        protected void gvCourses_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvCourses.EditIndex = e.NewEditIndex;
            BindCourses();

            // Populate faculty dropdown
            GridViewRow row = gvCourses.Rows[e.NewEditIndex];
            DropDownList ddlFaculty = (DropDownList)row.FindControl("ddlFaculty");

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var facultyList = db.Users
                    .Where(u => u.Role.ToLower() == "faculty")
                    .Select(u => u.Username)
                    .ToList();

                ddlFaculty.DataSource = facultyList;
                ddlFaculty.DataBind();

                // Set selected value
                string currentFaculty = (row.FindControl("ddlFaculty") as DropDownList).SelectedValue;
                ddlFaculty.SelectedValue = gvCourses.DataKeys[e.NewEditIndex].Value.ToString();
            }
        }

        protected void gvCourses_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int courseId = (int)gvCourses.DataKeys[e.RowIndex].Value;
            GridViewRow row = gvCourses.Rows[e.RowIndex];
            DropDownList ddlFaculty = (DropDownList)row.FindControl("ddlFaculty");

            string selectedFaculty = ddlFaculty.SelectedValue;

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var course = db.Courses.FirstOrDefault(c => c.CourseID == courseId);
                if (course != null)
                {
                    course.FacultyUsername = selectedFaculty;
                    db.SubmitChanges();
                }
            }

            gvCourses.EditIndex = -1;
            BindCourses();
        }

        protected void gvCourses_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvCourses.EditIndex = -1;
            BindCourses();
        }
    }
}
