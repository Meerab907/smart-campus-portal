﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class MarkAttendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadFacultyCourses();
            }
        }

        private void LoadFacultyCourses()
        {
            string facultyUsername = Session["Username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = db.Courses
                                .Where(c => c.FacultyUsername == facultyUsername)
                                .Select(c => new { c.CourseID, c.CourseName })
                                .ToList();

                ddlCourses.DataSource = courses;
                ddlCourses.DataTextField = "CourseName";
                ddlCourses.DataValueField = "CourseID";
                ddlCourses.DataBind();

                ddlCourses.Items.Insert(0, new ListItem("-- Select Course --", "0"));
            }
        }

        protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblMessage.Text = "";

            if (ddlCourses.SelectedValue != "0" && int.TryParse(ddlCourses.SelectedValue, out int courseId))
            {
                LoadStudentsForCourse(courseId);
            }
            else
            {
                pnlStudents.Visible = false;
            }
        }

        private void LoadStudentsForCourse(int courseId)
        {
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var students = (from sc in db.StudentCourses
                                join u in db.Users on sc.StudentUsername equals u.Username
                                where sc.CourseID == courseId && u.Role.ToLower() == "student"
                                select new
                                {
                                    u.Username,
                                    u.FullName
                                }).ToList();

                if (students.Count == 0)
                {
                    pnlStudents.Visible = false;
                    lblMessage.Text = "No students enrolled in this course.";
                    return;
                }

                DateTime today = DateTime.Today;

                var attendanceRecords = db.AttendanceRecords
                                          .Where(a => a.CourseID == courseId && a.AttendanceDate == today)
                                          .ToList();

                var attendanceList = students.Select(s => new
                {
                    s.Username,
                    s.FullName,
                    IsPresent = attendanceRecords.Any(a => a.Username == s.Username && a.IsPresent)
                }).ToList();

                gvStudents.DataSource = attendanceList;
                gvStudents.DataBind();
                pnlStudents.Visible = true;
            }
        }

        protected void btnSaveAttendance_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(ddlCourses.SelectedValue, out int courseId))
                return;

            DateTime today = DateTime.Today;

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var oldRecords = db.AttendanceRecords.Where(a => a.CourseID == courseId && a.AttendanceDate == today);
                db.AttendanceRecords.DeleteAllOnSubmit(oldRecords);
                db.SubmitChanges();

                foreach (GridViewRow row in gvStudents.Rows)
                {
                    string username = gvStudents.DataKeys[row.RowIndex].Value.ToString();
                    CheckBox chkPresent = (CheckBox)row.FindControl("chkPresent");

                    AttendanceRecord attendance = new AttendanceRecord
                    {
                        CourseID = courseId,
                        Username = username,
                        AttendanceDate = today,
                        IsPresent = chkPresent.Checked
                    };

                    db.AttendanceRecords.InsertOnSubmit(attendance);
                }

                db.SubmitChanges();

                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Attendance saved successfully!";
            }
        }
    }
}
