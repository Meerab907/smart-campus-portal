﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class ManageFaculty : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadFaculty();
                lblFormTitle.Text = "Add New Faculty";
                pnlForm.Visible = true;
            }
        }

        private void LoadFaculty()
        {
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var facultyList = db.Users
                    .Where(u => u.Role.ToLower() == "faculty")
                    .Select(u => new { u.Username, u.Email })
                    .ToList();

                gvFaculty.DataSource = facultyList;
                gvFaculty.DataBind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                lblMessage.Text = "All fields are required.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                bool exists = db.Users.Any(u => u.Username == username);
                if (exists)
                {
                    lblMessage.Text = "Username already exists.";
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                User newUser = new User
                {
                    Username = username,
                    Email = email,
                    Password = password, // ⚠️ Use hashing in production
                    Role = "faculty"
                };

                db.Users.InsertOnSubmit(newUser);
                db.SubmitChanges();

                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Faculty added successfully.";

                ClearForm();
                LoadFaculty();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
            lblFormTitle.Text = "Add New Faculty";
            pnlForm.Visible = true;
            lblMessage.Text = "";
        }

        private void ClearForm()
        {
            txtUsername.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            lblMessage.Text = "";
            gvFaculty.EditIndex = -1;
        }

        protected void gvFaculty_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvFaculty.EditIndex = e.NewEditIndex;
            LoadFaculty();
            pnlForm.Visible = false;
        }

        protected void gvFaculty_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvFaculty.EditIndex = -1;
            LoadFaculty();
            pnlForm.Visible = true;
        }

        protected void gvFaculty_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvFaculty.Rows[e.RowIndex];
            string username = gvFaculty.DataKeys[e.RowIndex].Value.ToString();
            string email = ((TextBox)row.Cells[1].Controls[0]).Text.Trim();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                User userToUpdate = db.Users.FirstOrDefault(u => u.Username == username && u.Role.ToLower() == "faculty");
                if (userToUpdate != null)
                {
                    userToUpdate.Email = email;
                    db.SubmitChanges();

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Faculty updated successfully.";
                }
            }

            gvFaculty.EditIndex = -1;
            LoadFaculty();
            pnlForm.Visible = true;
        }

        protected void gvFaculty_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string username = gvFaculty.DataKeys[e.RowIndex].Value.ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                User userToDelete = db.Users.FirstOrDefault(u => u.Username == username && u.Role.ToLower() == "faculty");
                if (userToDelete != null)
                {
                    db.Users.DeleteOnSubmit(userToDelete);
                    db.SubmitChanges();

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Faculty deleted successfully.";
                }
            }

            LoadFaculty();
            pnlForm.Visible = true;
        }
    }
}
