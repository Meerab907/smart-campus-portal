﻿using System;
using System.Web.UI;

namespace SmartCampusPortal
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string currentPage = Request.Url.AbsolutePath.ToLower();

                // Allow these pages without login
                if (currentPage.EndsWith("login.aspx") ||
                    currentPage.EndsWith("signup.aspx") ||
                    currentPage.EndsWith("default.aspx"))
                {
                    return;
                }

                // Redirect to login if session expired or missing
                if (Session["username"] == null || Session["role"] == null)
                {
                    Response.Redirect("~/Login.aspx");
                    return;
                }

                // Set welcome username label
                lblUsername.Text = Session["username"].ToString();

                // Show/hide menus based on role
                string role = Session["role"].ToString().ToLower();

                adminMenu.Visible = role == "admin";
                facultyMenu.Visible = role == "faculty";
                studentMenu.Visible = role == "student";

                // Set Dashboard hyperlink dynamically based on role
                switch (role)
                {
                    case "admin":
                        lnkDashboard.NavigateUrl = "~/AdminDashboard.aspx";
                        break;
                    case "faculty":
                        lnkDashboard.NavigateUrl = "~/FacultyDashboard.aspx";
                        break;
                    case "student":
                        lnkDashboard.NavigateUrl = "~/StudentDashboard.aspx";
                        break;
                    default:
                        lnkDashboard.NavigateUrl = "~/Default.aspx";
                        break;
                }
            }
        }

        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("~/Login.aspx");
        }
    }
}
