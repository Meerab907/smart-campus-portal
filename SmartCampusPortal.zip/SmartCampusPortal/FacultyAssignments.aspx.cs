﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class FacultyAssignments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadCourses();
            }
        }

        private void LoadCourses()
        {
            string facultyUsername = Session["username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = db.Courses
                    .Where(c => c.FacultyUsername == facultyUsername)
                    .Select(c => new { c.CourseID, c.CourseName })
                    .ToList();

                ddlCourses.DataSource = courses;
                ddlCourses.DataTextField = "CourseName";
                ddlCourses.DataValueField = "CourseID";
                ddlCourses.DataBind();

                ddlCourses.Items.Insert(0, new System.Web.UI.WebControls.ListItem("-- Select Course --", ""));

                gvAssignments.DataSource = null;
                gvAssignments.DataBind();
            }
        }

        protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadAssignments();
        }

        private void LoadAssignments()
        {
            if (string.IsNullOrEmpty(ddlCourses.SelectedValue))
                return;

            int courseId = Convert.ToInt32(ddlCourses.SelectedValue);

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var assignments = db.Assignments
                    .Where(a => a.CourseID == courseId)
                    .Select(a => new
                    {
                        a.Title,
                        a.Description,
                        a.DueDate,
                        a.IsGraded
                    }).ToList();

                gvAssignments.DataSource = assignments;
                gvAssignments.DataBind();
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ddlCourses.SelectedValue))
            {
                lblMessage.Text = "Please select a course.";
                return;
            }

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                Assignment newAssignment = new Assignment
                {
                    Title = txtTitle.Text,
                    Description = txtDescription.Text,
                    DueDate = Convert.ToDateTime(txtDueDate.Text),
                    IsGraded = false,
                    CourseID = Convert.ToInt32(ddlCourses.SelectedValue)
                };

                db.Assignments.InsertOnSubmit(newAssignment);
                db.SubmitChanges();

                lblMessage.Text = "Assignment uploaded successfully.";

                // Clear fields
                txtTitle.Text = "";
                txtDescription.Text = "";
                txtDueDate.Text = "";

                LoadAssignments();
            }
        }
    }
}
