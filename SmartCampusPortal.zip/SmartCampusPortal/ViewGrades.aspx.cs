﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ViewGrades : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadGrades();
            }
        }

        private void LoadGrades()
        {
            string studentUsername = Session["Username"]?.ToString();
            if (string.IsNullOrEmpty(studentUsername))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            var grades = from sub in db.AssignmentSubmissions
                         join a in db.Assignments on sub.AssignmentID equals a.AssignmentID
                         join c in db.Courses on a.CourseID equals c.CourseID
                         where sub.StudentUsername == studentUsername && sub.IsGraded == true
                         select new
                         {
                             c.CourseName,
                             AssignmentTitle = a.Title,
                             sub.Grade,
                             sub.SubmissionDate
                         };

            gvGrades.DataSource = grades.ToList();
            gvGrades.DataBind();

            if (!grades.Any())
                lblMessage.Text = "No graded assignments found.";
        }
    }
}
