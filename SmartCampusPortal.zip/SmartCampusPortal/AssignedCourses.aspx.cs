﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class AssignedCourses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadAssignedCourses();
            }
        }

        private void LoadAssignedCourses()
        {
            try
            {
                string facultyUsername = Session["username"].ToString();

                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var courses = db.Courses
                        .Where(c => c.FacultyUsername == facultyUsername)
                        .Select(c => new
                        {
                            c.CourseName,
                            c.Credits
                        })
                        .ToList();

                    if (courses.Any())
                    {
                        gvCourses.DataSource = courses;
                        gvCourses.DataBind();
                        lblMessage.Text = "";
                    }
                    else
                    {
                        gvCourses.DataSource = null;
                        gvCourses.DataBind();
                        lblMessage.Text = "No courses assigned yet.";
                    }
                }
            }
            catch (Exception)
            {
                lblMessage.Text = "An error occurred while loading assigned courses.";
            }
        }
    }
}
