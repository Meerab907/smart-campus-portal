﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;

namespace SmartCampusPortal
{
    public partial class ExportPerformance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
                Response.Redirect("~/Login.aspx");

            if (!IsPostBack)
                LoadCourses();
        }

        private void LoadCourses()
        {
            string facultyUsername = Session["username"].ToString();
            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = db.Courses
                                .Where(c => c.FacultyUsername == facultyUsername)
                                .Select(c => new { c.CourseID, c.CourseName })
                                .ToList();

                ddlCourses.DataSource = courses;
                ddlCourses.DataTextField = "CourseName";
                ddlCourses.DataValueField = "CourseID";
                ddlCourses.DataBind();

                ddlCourses.Items.Insert(0, new ListItem("Select a course", ""));
            }
        }

        protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadPerformance();
        }

        private void LoadPerformance()
        {
            int courseId = int.Parse(ddlCourses.SelectedValue);

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var students = (from u in db.Users
                                join s in db.Submissions on u.UserID equals s.UserID
                                join a in db.Assignments on s.AssignmentID equals a.AssignmentID
                                where a.CourseID == courseId
                                group s by new { u.FullName, u.Email, u.UserID } into g
                                select new
                                {
                                    StudentName = g.Key.FullName,
                                    g.Key.Email,
                                    AverageGrade = g.Average(x => x.Grade != null ? Convert.ToDouble(x.Grade) : 0).ToString("F1"),
                                    AttendancePercentage = GetAttendancePercentage(db, g.Key.UserID, courseId)
                                }).ToList();

                gvPerformance.DataSource = students;
                gvPerformance.DataBind();
            }
        }

        private string GetAttendancePercentage(SmartCampusDataDataContext db, int userId, int courseId)
        {
            var total = db.Attendances.Count(a => a.CourseID == courseId && a.UserID == userId);
            var present = db.Attendances.Count(a => a.CourseID == courseId && a.UserID == userId && a.IsPresent);

            if (total == 0) return "N/A";
            double percent = (double)present / total * 100;
            return percent.ToString("F1");
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=PerformanceReport.xls");
            Response.ContentType = "application/ms-excel";
            Response.ContentEncoding = Encoding.UTF8;

            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            gvPerformance.RenderControl(hw);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            // Needed to export GridView
        }
    }
}
