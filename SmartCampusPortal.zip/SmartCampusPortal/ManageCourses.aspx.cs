﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class ManageCourses : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCourses();
                LoadPrerequisitesDropdown();
                LoadFacultyDropdown();
                LoadStudentsDropdown();
                LoadCoursesForAssignment();
            }
        }

        private void LoadCourses()
        {
            var courses = db.Courses.Select(c => new
            {
                c.CourseID,
                c.CourseName,
                c.Credits,
                Prerequisite = c.PrerequisiteCourseID != null
                    ? db.Courses.FirstOrDefault(p => p.CourseID == c.PrerequisiteCourseID).CourseName
                    : "None",
                c.FacultyUsername
            }).ToList();

            gvCourses.DataSource = courses;
            gvCourses.DataBind();
        }

        private void LoadPrerequisitesDropdown()
        {
            ddlPrerequisite.DataSource = db.Courses.ToList();
            ddlPrerequisite.DataTextField = "CourseName";
            ddlPrerequisite.DataValueField = "CourseID";
            ddlPrerequisite.DataBind();
            ddlPrerequisite.Items.Insert(0, new System.Web.UI.WebControls.ListItem("None", ""));
        }

        private void LoadFacultyDropdown()
        {
            var faculty = db.Users.Where(u => u.Role.ToLower() == "faculty").ToList();
            ddlFaculty.DataSource = faculty;
            ddlFaculty.DataTextField = "Username";
            ddlFaculty.DataValueField = "Username";
            ddlFaculty.DataBind();
            ddlFaculty.Items.Insert(0, new System.Web.UI.WebControls.ListItem("None", ""));
        }

        private void LoadStudentsDropdown()
        {
            var students = db.Users.Where(u => u.Role.ToLower() == "student").ToList();
            ddlStudent.DataSource = students;
            ddlStudent.DataTextField = "Username";
            ddlStudent.DataValueField = "Username";
            ddlStudent.DataBind();
        }

        private void LoadCoursesForAssignment()
        {
            ddlCourseToAssign.DataSource = db.Courses.ToList();
            ddlCourseToAssign.DataTextField = "CourseName";
            ddlCourseToAssign.DataValueField = "CourseID";
            ddlCourseToAssign.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (hfCourseID.Value == "")
            {
                Course c = new Course
                {
                    CourseName = txtCourseName.Text.Trim(),
                    Credits = int.Parse(txtCredits.Text.Trim()),
                    PrerequisiteCourseID = string.IsNullOrEmpty(ddlPrerequisite.SelectedValue) ? (int?)null : int.Parse(ddlPrerequisite.SelectedValue),
                    FacultyUsername = ddlFaculty.SelectedValue
                };
                db.Courses.InsertOnSubmit(c);
                db.SubmitChanges();
                lblMessage.Text = "Course added successfully!";
            }
            else
            {
                int id = int.Parse(hfCourseID.Value);
                Course c = db.Courses.Single(x => x.CourseID == id);
                c.CourseName = txtCourseName.Text.Trim();
                c.Credits = int.Parse(txtCredits.Text.Trim());
                c.PrerequisiteCourseID = string.IsNullOrEmpty(ddlPrerequisite.SelectedValue) ? (int?)null : int.Parse(ddlPrerequisite.SelectedValue);
                c.FacultyUsername = ddlFaculty.SelectedValue;
                db.SubmitChanges();
                lblMessage.Text = "Course updated successfully!";
            }

            ClearForm();
            LoadCourses();
            LoadCoursesForAssignment();
        }

        protected void btnAssignCourse_Click(object sender, EventArgs e)
        {
            string studentUsername = ddlStudent.SelectedValue;
            int courseId = int.Parse(ddlCourseToAssign.SelectedValue);

            // Check if already assigned
            bool alreadyAssigned = db.StudentCourses.Any(x => x.StudentUsername == studentUsername && x.CourseID == courseId);
            if (alreadyAssigned)
            {
                lblAssignMessage.Text = "Student is already assigned this course.";
                return;
            }

            StudentCourse sc = new StudentCourse
            {
                StudentUsername = studentUsername,
                CourseID = courseId
            };
            db.StudentCourses.InsertOnSubmit(sc);
            db.SubmitChanges();
            lblAssignMessage.Text = "Course assigned to student successfully!";
        }

        protected void gvCourses_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "EditCourse")
            {
                Course c = db.Courses.Single(x => x.CourseID == id);
                txtCourseName.Text = c.CourseName;
                txtCredits.Text = c.Credits.ToString();
                ddlPrerequisite.SelectedValue = c.PrerequisiteCourseID?.ToString() ?? "";
                ddlFaculty.SelectedValue = c.FacultyUsername ?? "";
                hfCourseID.Value = c.CourseID.ToString();
                lblFormTitle.Text = "Edit Course";
                btnSave.Text = "Update";
                btnCancel.Visible = true;
                lblMessage.Text = "";
            }
            else if (e.CommandName == "DeleteCourse")
            {
                Course c = db.Courses.Single(x => x.CourseID == id);
                db.Courses.DeleteOnSubmit(c);
                db.SubmitChanges();
                lblMessage.Text = "Course deleted.";
                LoadCourses();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtCourseName.Text = "";
            txtCredits.Text = "";
            ddlPrerequisite.SelectedIndex = 0;
            ddlFaculty.SelectedIndex = 0;
            hfCourseID.Value = "";
            lblFormTitle.Text = "Add New Course";
            btnSave.Text = "Save";
            btnCancel.Visible = false;
        }
    }
}
