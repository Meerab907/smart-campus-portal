﻿using System;
using System.IO;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class ManageSubmissions : System.Web.UI.Page
    {
        private readonly string FeedbackUploadFolder = "~/Uploads/FeedbackFiles/";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Security check: Only logged-in faculty allowed
            if (Session["username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadFacultyAssignments();
            }
        }

        private void LoadFacultyAssignments()
        {
            string currentFacultyUsername = Session["username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var assignments = (from a in db.Assignments
                                   join c in db.Courses on a.CourseID equals c.CourseID
                                   where c.FacultyUsername == currentFacultyUsername
                                   select new
                                   {
                                       a.AssignmentID,
                                       a.Title
                                   }).ToList();

                ddlAssignments.DataSource = assignments;
                ddlAssignments.DataTextField = "Title";
                ddlAssignments.DataValueField = "AssignmentID";
                ddlAssignments.DataBind();

                ddlAssignments.Items.Insert(0, new System.Web.UI.WebControls.ListItem("-- Select Assignment --", ""));
            }
        }

        protected void ddlAssignments_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            LoadSubmissions();
        }

        private void LoadSubmissions()
        {
            if (string.IsNullOrEmpty(ddlAssignments.SelectedValue))
            {
                gvSubmissions.DataSource = null;
                gvSubmissions.DataBind();
                return;
            }

            int assignmentId = int.Parse(ddlAssignments.SelectedValue);

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var submissions = (from s in db.Submissions
                                   join u in db.Users on s.UserID equals u.UserID
                                   where s.AssignmentID == assignmentId
                                   select new
                                   {
                                       s.SubmissionID,
                                       StudentUsername = u.Username,
                                       SubmissionDate = s.SubmissionDate,
                                       Grade = s.Grade ?? "",
                                       SubmissionFilePath = s.FeedbackFilePath, // You can change this if you have separate column for submitted file
                                       FeedbackFilePath = s.FeedbackFilePath
                                   }).ToList();

                gvSubmissions.DataSource = submissions;
                gvSubmissions.DataBind();
            }
        }

        protected void gvSubmissions_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            gvSubmissions.EditIndex = e.NewEditIndex;
            LoadSubmissions();
        }

        protected void gvSubmissions_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            gvSubmissions.EditIndex = -1;
            LoadSubmissions();
        }

        protected void gvSubmissions_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            int submissionId = Convert.ToInt32(gvSubmissions.DataKeys[e.RowIndex].Value);
            GridViewRow row = gvSubmissions.Rows[e.RowIndex];

            // Get Grade TextBox value
            string grade = ((System.Web.UI.WebControls.TextBox)row.FindControl("txtGrade")).Text.Trim();

            // Get FileUpload control
            var fuFeedback = (System.Web.UI.WebControls.FileUpload)row.FindControl("fuFeedback");

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var submission = db.Submissions.FirstOrDefault(s => s.SubmissionID == submissionId);
                if (submission != null)
                {
                    submission.Grade = grade;

                    // Handle file upload if a new file is selected
                    if (fuFeedback.HasFile)
                    {
                        // Create folder if not exists
                        string uploadFolder = Server.MapPath(FeedbackUploadFolder);
                        if (!Directory.Exists(uploadFolder))
                            Directory.CreateDirectory(uploadFolder);

                        string fileExt = Path.GetExtension(fuFeedback.FileName);
                        string allowedExtensions = ".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.png,.zip";

                        if (!allowedExtensions.Contains(fileExt.ToLower()))
                        {
                            lblMessage.ForeColor = System.Drawing.Color.Red;
                            lblMessage.Text = "Invalid file type for feedback. Allowed types: " + allowedExtensions;
                            return;
                        }

                        string newFileName = $"feedback_sub_{submission.SubmissionID}_{DateTime.Now.ToString("yyyyMMddHHmmss")}{fileExt}";
                        string filePath = Path.Combine(uploadFolder, newFileName);

                        fuFeedback.SaveAs(filePath);

                        // Save relative path to database (web-accessible)
                        submission.FeedbackFilePath = FeedbackUploadFolder.TrimStart('~') + newFileName;
                    }

                    db.SubmitChanges();

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Submission updated successfully.";
                }
            }

            gvSubmissions.EditIndex = -1;
            LoadSubmissions();
        }
    }
}
