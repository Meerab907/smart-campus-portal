﻿using System;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCounts();
                LoadRecentActivity();
            }
        }

        // Load total student and faculty counts
        private void LoadCounts()
        {
            try
            {
                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    lblTotalStudents.Text = db.Users.Count(u => u.Role.ToLower() == "student").ToString();
                    lblTotalFaculty.Text = db.Users.Count(u => u.Role.ToLower() == "faculty").ToString();
                }
            }
            catch (Exception ex)
            {
                lblTotalStudents.Text = "Error";
                lblTotalFaculty.Text = "Error";
                // Optional: log error or show message
            }
        }

        // Load 5 most recent activity log records
        private void LoadRecentActivity()
        {
            try
            {
                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    var recentActivities = db.ActivityLogs
                        .OrderByDescending(a => a.ActivityTime)
                        .Take(5)
                        .Select(a => new
                        {
                            a.Username,
                            a.Action,
                            a.ActivityTime
                        }).ToList();

                    gvRecentActivity.DataSource = recentActivities;
                    gvRecentActivity.DataBind();
                }
            }
            catch (Exception ex)
            {
                // Optional: log or handle error; here we just swallow it silently
            }
        }
    }
}
