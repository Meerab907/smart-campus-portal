﻿using System.Configuration;
using System.Data.Linq.Mapping;

namespace SmartCampusPortal
{
    public partial class SmartCampusDataDataContext
    {
        // Use the default connection string from web.config
        public SmartCampusDataDataContext()
            : base(ConfigurationManager.ConnectionStrings["SmartCampusDBConnectionString"].ConnectionString, mappingSource)
        {
            OnCreated();
        }
    }
}
