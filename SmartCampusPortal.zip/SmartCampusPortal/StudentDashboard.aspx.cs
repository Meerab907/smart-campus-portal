﻿using System;
using System.Linq;
using System.Web.UI.WebControls;

namespace SmartCampusPortal
{
    public partial class StudentDashboard : System.Web.UI.Page
    {
        SmartCampusDataDataContext db = new SmartCampusDataDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadRegisteredCourses();
                pnlAssignments.Visible = false;
                pnlSubmitAssignment.Visible = false;
            }
        }

        private string CurrentUsername => User.Identity.Name;

        private void LoadRegisteredCourses()
        {
            var courses = from sc in db.StudentCourses
                          join c in db.Courses on sc.CourseID equals c.CourseID
                          where sc.StudentUsername == CurrentUsername
                          select new
                          {
                              c.CourseID,
                              c.CourseName,
                              c.Credits
                          };

            gvCourses.DataSource = courses.ToList();
            gvCourses.DataBind();
        }

        protected void gvCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            int courseId = (int)gvCourses.SelectedDataKey.Value;

            var course = db.Courses.SingleOrDefault(c => c.CourseID == courseId);
            if (course == null)
            {
                lblError.Text = "Selected course not found.";
                return;
            }

            lblSelectedCourse.Text = course.CourseName;
            LoadAssignments(courseId);
            pnlAssignments.Visible = true;
            pnlSubmitAssignment.Visible = false;
            lblMessage.Text = "";
            lblError.Text = "";
        }

        private void LoadAssignments(int courseId)
        {
            var assignments = db.Assignments.Where(a => a.CourseID == courseId)
                                            .Select(a => new
                                            {
                                                a.AssignmentID,
                                                a.Title,
                                                a.DueDate,
                                                IsGraded = a.IsGraded ? "Yes" : "No"
                                            }).ToList();

            gvAssignments.DataSource = assignments;
            gvAssignments.DataBind();
        }

        protected void gvAssignments_SelectedIndexChanged(object sender, EventArgs e)
        {
            int assignmentId = (int)gvAssignments.SelectedDataKey.Value;
            var assignment = db.Assignments.SingleOrDefault(a => a.AssignmentID == assignmentId);
            if (assignment == null)
            {
                lblError.Text = "Assignment not found.";
                return;
            }

            lblAssignmentTitle.Text = assignment.Title;

            // Check if student has already submitted
            var submission = db.Submissions.SingleOrDefault(s => s.AssignmentID == assignmentId && s.StudentUsername == CurrentUsername);
            if (submission != null)
            {
                lblSubmitMessage.Text = "You have already submitted this assignment.";
                pnlSubmitAssignment.Visible = false;
            }
            else
            {
                pnlSubmitAssignment.Visible = true;
                lblSubmitMessage.Text = "";
            }

            lblError.Text = "";
        }

        protected void btnSubmitAssignment_Click(object sender, EventArgs e)
        {
            lblSubmitMessage.Text = "";
            lblSubmitError.Text = "";

            if (!fuAssignment.HasFile && string.IsNullOrWhiteSpace(txtNotes.Text))
            {
                lblSubmitError.Text = "Please upload a file or enter notes.";
                return;
            }

            int assignmentId = (int)gvAssignments.SelectedDataKey.Value;

            // Save file if uploaded
            string filePath = null;
            if (fuAssignment.HasFile)
            {
                try
                {
                    string fileName = System.IO.Path.GetFileName(fuAssignment.FileName);
                    string savePath = Server.MapPath("~/Uploads/Assignments/");
                    if (!System.IO.Directory.Exists(savePath))
                    {
                        System.IO.Directory.CreateDirectory(savePath);
                    }
                    string fullPath = System.IO.Path.Combine(savePath, fileName);
                    fuAssignment.SaveAs(fullPath);
                    filePath = "~/Uploads/Assignments/" + fileName;
                }
                catch (Exception ex)
                {
                    lblSubmitError.Text = "File upload failed: " + ex.Message;
                    return;
                }
            }

            var submission = new Submission
            {
                AssignmentID = assignmentId,
                StudentUsername = CurrentUsername,
                FilePath = filePath,
                Notes = txtNotes.Text.Trim(),
                SubmissionDate = DateTime.Now,
                IsGraded = false
            };

            db.Submissions.InsertOnSubmit(submission);
            db.SubmitChanges();

            lblSubmitMessage.Text = "Assignment submitted successfully!";
            pnlSubmitAssignment.Visible = false;
            txtNotes.Text = "";
        }
    }
}
