﻿using System;
using System.IO;
using System.Linq;

namespace SmartCampusPortal
{
    public partial class UploadLecture : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Authentication check
            if (Session["username"] == null || Session["role"] == null || Session["role"].ToString().ToLower() != "faculty")
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadCourses();
            }
        }

        private void LoadCourses()
        {
            string facultyUsername = Session["username"].ToString();

            using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
            {
                var courses = db.Courses
                                .Where(c => c.FacultyUsername == facultyUsername)
                                .Select(c => new { c.CourseID, c.CourseName })
                                .ToList();

                ddlCourses.DataSource = courses;
                ddlCourses.DataTextField = "CourseName";
                ddlCourses.DataValueField = "CourseID";
                ddlCourses.DataBind();

                ddlCourses.Items.Insert(0, new System.Web.UI.WebControls.ListItem("-- Select Course --", ""));
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (ddlCourses.SelectedIndex == 0 || string.IsNullOrWhiteSpace(txtTitle.Text) || !fileUpload.HasFile)
            {
                lblMessage.Text = "Please fill all fields and select a file.";
                return;
            }

            try
            {
                string fileName = Path.GetFileName(fileUpload.FileName);
                string uploadFolder = Server.MapPath("~/Uploads/LectureMaterials/");
                string filePath = Path.Combine(uploadFolder, fileName);
                fileUpload.SaveAs(filePath);

                string relativePath = "~/Uploads/LectureMaterials/" + fileName;

                using (SmartCampusDataDataContext db = new SmartCampusDataDataContext())
                {
                    LectureMaterial lecture = new LectureMaterial
                    {
                        CourseID = int.Parse(ddlCourses.SelectedValue),
                        Title = txtTitle.Text.Trim(),
                        FilePath = relativePath,
                        UploadedBy = Session["username"].ToString(),
                        UploadDate = DateTime.Now
                    };

                    db.LectureMaterials.InsertOnSubmit(lecture);
                    db.SubmitChanges();
                }

                lblMessage.ForeColor = System.Drawing.Color.Green;
                lblMessage.Text = "Lecture material uploaded successfully.";
                txtTitle.Text = "";
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Error: " + ex.Message;
            }
        }
    }
}
